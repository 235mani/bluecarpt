/* login password toggle*/
function login_pwd() {
  var login_pwd_ip = document.getElementById("login-pwd");

  if (login_pwd_ip.type == "password") {
    login_pwd_ip.type = "text";
  } else {
    login_pwd_ip.type = "password";
  }
  
}
/* sign-up password eye toggle*/

function signup_pwd() {
  var signup_pwd_ip = document.getElementById("signup-pwd");
  var eye_hide = document.getElementById("signup-pwd-hide");
  var eye_unhide = document.getElementById("signup-pwd-unhide");

  if (signup_pwd_ip.type == "password") {
    signup_pwd_ip.type = "text";
    eye_hide.style.display="block";
    eye_unhide.style.display="none";

  } else {
    signup_pwd_ip.type = "password";
    eye_hide.style.display="none";
    eye_unhide.style.display="block";
  }  
}

/* LOGIN password eye toggle*/

function login_pwd() {
  var login_pwd_ip = document.getElementById("login-pwd");
  var login_eye_hide = document.getElementById("login-pwd-hide");
  var login_eye_unhide = document.getElementById("login-pwd-unhide");

  if (login_pwd_ip.type == "password") {
    login_pwd_ip.type = "text";
    login_eye_hide.style.display="block";
    login_eye_unhide.style.display="none";

  } else {
    login_pwd_ip.type = "password";
    login_eye_hide.style.display="none";
    login_eye_unhide.style.display="block";
  }
  
}

  /*function and convention halls divs view*/
function function_halls(){
  var fun=document.getElementById("function-halls-div");
  var conv=document.getElementById("convention-halls-div");
  fun.style.display="block";
  conv.style.display="none";
}
function convention_halls(){
  var fun=document.getElementById("function-halls-div");
  var conv=document.getElementById("convention-halls-div");
  fun.style.display="none";
  conv.style.display="block";
}

// function camera(){
//   var sel=document.getElementById("camera");
//   //var display = select.options[select.selectedIndex].value;
//   var opt = sel.options[sel.selectedIndex];
//   alert(opt);
//   //document.getElementById("select_val").value=display;
// }

// function hall_card(){
//   window.location="hall_view.php";
// }

/*gallery tab layout in view hall page*/
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
  
}



  /*for dropdown menues*/
$(document).ready(function(){
  $('#item1').on("click", function(e){
    $(this).next('div').toggle();
    $('#level_2in2_drop').css('display','none');
    e.stopPropagation();
    e.preventDefault();
  });
});

$(document).ready(function(){
  $('#item2').on("click", function(e){
    $(this).next('div').toggle();
    $('#level_1in2_drop').css('display','none');
    e.stopPropagation();
    e.preventDefault();
  });
});


/*5-sec popup form js code*/
$(document).ready(function()
{
  setTimeout(function()
  {
    $('#main').css('display','block');
  },5000);
});

$('#close-btn').click(function()
{
  $('#main').css('display','none');
});

$('#close-btn-pop-signup').click(function()
{
  $('#main').css('display','none');
});

$('#close-btn-pop-login').click(function()
{
  $('#main').css('display','none');
});


// $('#photography').change(function(){
//   var photography_value = $("#photography :selected").val();
//   $("#selected_photography").html(photography_value);
// });

// $('#album').change(function(){
//   var album_value = $("#album :selected").val();
//   $("#selected_album").html(album_value);
// });


// $(document).ready(function(){
// var final_bill = parseInt($("input[name='hall_rent']").val()); 
//       $('input:radio[name=Photographer_rent]').change(function() {
          
//           var Photographer_rent = $(this).val();
//           if (Photographer_rent!=0) {
//             $('#photography').removeAttr('disabled');
//             $('#album').removeAttr('disabled');

//                   var photography_value = $("#photography :selected").val();
//                   var album_value = $("#album :selected").val();
//                   var photography_rent = $("input[name='Photographer_rent']:checked").val();

//                   var final_bill =final_bill+parseInt(photography_value)+parseInt(album_value)+parseInt(photography_rent);
//                   $("#final_bill").html(final_bill);
//           }else{
//             $('#photography').attr('disabled','disabled');
//             $('#album').attr('disabled','disabled');
                
//                   // var hall_rent = $("input[name='hall_rent']").val();
//                   var photography_value = '0'
//                   var album_value = '0'
//                   var photography_rent = '0'

//                   var final_bill =final_bill+parseInt(photography_value)+parseInt(album_value)+parseInt(photography_rent);
//                   $("#final_bill").html(final_bill);
//           }
//       });
// });

$(document).ready(function){
      var final_bill =$("input[name='hall_rent']").val();
      
      $("#final_bill").html(final_bill);    
}


// $("#final_bill").html(album_value);

/*timing of posted hall details

var dt = new Date();
document.getElementById("date").innerHTML = dt.toLocaleDateString();
var time = new Date();
document.getElementById("time").innerHTML = dt.toLocaleTimeString();
*/



$(document).ready(function () {

  /*tooltip*/
  $('[data-toggle="tooltip"]').tooltip();
  $('#tooltip').on('click',function(){
    $('[data-toggle="tooltip"]').tooltip();
  });

  /*final booking check out button*/  
  $('#final-book').on('click',function(){
    // $('#Booking').modal();
      if($("#booking_name").val() !="" && 
          $("#booking_email").val() !="" &&
          $("#booking_phone").val() !="" &&
          $("#booking_address").val() !="" &&
          $("#booking_pincode").val().length =="6" &&
          $("#start_date").val() !="" &&
          $("#end_date").val() !="" &&
          $("#start_time").val() !="" &&
          $("#end_time").val() !="" ) 
      {
         $('#Booking').modal('show');
         // $(this).closest("form").submit(); 
      }
      else{
        alert("Please fill out required fields");
      }
  });

  /*(logout) get otp js*/
      // $('.custom_get_otp').on('click', function(){
      //   if ($('#mail_verify').val()){
      //       $('.custom_get_otp').prop('value', 'Re-send OTP');
      //       $('.logout-otp-form').css('display', 'block');    
      //   }
      //   else{
      //     $('.logout-otp-form').css('display', 'none');
      //     window.alert("enter valid mail");
          
      //   }
      // });
  /*(logout) verify otp btn clicked*/
      // $('#verify_otp').on('click', function(){
        
      // window.alert('Under construction....!!!!!!!');
      // });

  /*(logout) otp btn clr change js*/
      // $('#otp').on('input change', function () {
      //     if ($(this).val().length==6) {
      //         $('#verify_otp').prop('disabled', false);
      //         $('#verify_otp').css('background-color', 'green');
      //         $('#verify_otp').css('border', 'green');
      //     }
      //     else {
      //         $('#verify_otp').prop('disabled', true);
      //         $('#verify_otp').css('background-color', 'black');

      //     }
      // });

  /*(view card page) Time and Date picker code*/

      $("#valid_date").datepicker({ 
            
            autoclose: true, 
            todayHighlight: true,
            startDate:"+0d"
      });
      
      var today = new Date();
      var n=5;
      $("#datefrom").datepicker({ 
            autoclose: true,
            format : "dd/MM/yy" , 
            todayHighlight: true,
            startDate:"+`{n}`d"
      });

      $("#dateto").datepicker({ 
            autoclose: true, 
            todayHighlight: true,
            startDate:"+0d"
      });

      $("#time1 ").clockpicker({ 
            autoclose: true  ,
            // twelvehour: true
      });

    $("#time2").clockpicker({ 
            autoclose: true  ,
            // twelvehour: true
      });



    $('#coursetype').change(function(){
        $('#final_book').prop('disabled', true);
        $('#final_book').css('background-color', 'black');
        
    });

  /*(view more page ) payment option selection to get payment UPI field*/

        var courses = ['1','2','3']; // available courses

        $('#coursetype').on('change', function() {
             var val = $('#coursetype').val();
             if(val==1){
              $('#phone_pe').css('display', 'block');
              $('#g_pay').css('display', 'none');
              $('#paytm').css('display', 'none');
             }
             if(val==2){
              $('#phone_pe').css('display', 'none');
              $('#g_pay').css('display', 'block');
              $('#paytm').css('display', 'none');
             }
             if(val==3){
              $('#phone_pe').css('display', 'none');
              $('#g_pay').css('display', 'none');
              $('#paytm').css('display', 'block');
             }
             
        });

/*(view more page ) Book button enable and disable*/
        $("#upi , #upi , #upi").on('input change', function () {
            if ($(this).val().length==10) {
                $('#final_book').prop('disabled', false);
                $('#final_book').css('background-color', 'green');
                $('#final_book').css('border', 'green');
            }
            else {
                $('#final_book').prop('disabled', true);
                $('#final_book').prop('value', 'Enter valid Number');
                $('#final_book').css('background-color', 'black');
            }
        });
    

/*
-------------------THIS CODE WILL ALSO WORK-----------------
document.getElementById("upi_id").addEventListener("keyup", function() {
    var nameInput = document.getElementById('upi_id').value;
    if (nameInput != "") {
        document.getElementById('final_book').removeAttribute("disabled");
        document.getElementById('final_book').style.backgroundColor="green";
    } else {
        document.getElementById('final_book').setAttribute("disabled", true);
        document.getElementById('final_book').style.backgroundColor="black";
    }
});
*/
/*(card view) on hitting book button*/
      $('#final_book').on('click', function(){
        var val = $('#coursetype').val();
      window.alert(val);
      });

});


document.getElementById("defaultOpen").click();