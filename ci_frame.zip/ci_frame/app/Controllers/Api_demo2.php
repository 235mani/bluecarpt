<?php namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\user_db;

class Api_demo2 extends BaseController
{
	public function findall()
	{
		$auth = new user_db();
		$result = $auth->findAll();

		if ($auth) {
			return $this->response->setStatusCode(200)
								  ->setJSON($result);		
		}
		else{
			return $this->response->setStatusCode(400);
		}	

	}

	public function findone($id)
	{

		$auth = new user_db();
		$result = $auth->find($id);
		// $result = $auth->where(['id'=>$id])
		// 				->find();

		if ($auth) {
			return $this->response->setStatusCode(200)
								  ->setJSON($result);		
		}
		else{
			return $this->response->setStatusCode(400)
									->setContentType('text/plain')
									->setBody("failed due to some issue");
		}	

	}

	public function create($id)
	{

		$auth = new user_db();
		$result = $auth->find($id);
		// $result = $auth->where(['id'=>$id])
		// 				->find();

		if ($auth) {
			return $this->response->setStatusCode(200)
								  ->setJSON($result);		
		}
		else{
			return $this->response->setStatusCode(400)
									->setContentType('text/plain')
									->setBody("failed due to some issue");
		}	

	}	
}
