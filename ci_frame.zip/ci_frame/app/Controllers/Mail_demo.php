<?php namespace App\Controllers;
use App\Controllers\BaseController;
class Mail_demo extends BaseController
{

    public function index()
    {

                try {
                    $email = \Config\Services::email();

                    $config['protocol'] = 'mail';
                    $config['SMTPHost'] = 'https://bc3.000webhostapp.com';
                    $config['SMTPPort'] = '465';
                    $config['SMTPTimeout'] = '5';
                    $config['SMTPUser'] = 'itsmanipersonal@gmail.com';
                    $config['SMTPPass'] = 'manipwd235';
                    //'cztwvnvjfdlgkdop';
                    // $config['recipients'] = 'tmanideep235@gmail.com';

                    $config['charset']  = 'utf-8';
                    $config['mailType'] = 'text';

                    $email->initialize($config);


                    $email->setFrom('itsmanipersonal@gmail.com'); //our site personal mail
                    $email->setTo('111manideep@gmail.com');   //our site official mail
                    // $email->setCC('another@another-gmail.com');
                    // $email->setBCC('them@their-gmail.com');

                    $email->setSubject('Email Test');
                    $email->setMessage('trials');
                    //$email->setHeader('111manideep@gmail.com', 'manideep');

                    
                    if (! $email->send())
                    {
                        echo $email->printDebugger();
                    }
                    else{
                        echo "sent";
                    }
                } catch (\Exception $e) {
                    echo $e;
                }
    }
}
