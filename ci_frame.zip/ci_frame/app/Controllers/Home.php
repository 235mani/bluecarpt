<?php namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\user_db;
use App\Models\hall_db;

class Home extends BaseController
{
	public function index()
	{
		$session=session();
		if ($session->get('email')!=null) {
			$data = ['search'=>''];
			return view('user_home',$data);
		}else{
			$data=['search'=>''];
			return view('home_page',$data);
		}
	}
	public function hall_details($data){
		$send['get_data']=$data;
		return view("hall_details",$send);
	}
	public function booking_page($data){
		$send_book_page['get_book_data']=$data;
		return view("booking",$send_book_page);
	}
	public function user_home(){
		$session=session();
		if ($session->get('email')!=null) {
			$data = ['search'=>''];
			return view('user_home',$data);
		}else{
			$data=['search'=>''];
			return view('home_page',$data);
		}		
	}
	public function user_profile(){
		$session=session();
		if ($session->get('email')!=null) {
			return view('user_profile');
		}else{
			$data=['search'=>''];
			return view('home_page',$data);
		}
		
	}
	public function reg_validate(){
		$verify = $this->validate([
			// 'reg_name'=>'alpha_numeric_space|min_length[3]|max_length[30]',
			// 'reg_pwd'=>'min_length[5]|max_length[20]',
			// 'reg_email'=>'min_length[6]|max_length[25]|valid_email',
			// 'reg_mobile'=>'min_length[10]|max_length[10]|is_unique[user_details.mobile]|regex_match[/^[7-9]{1}[0-9]{9}$/]',
			// 'reg_address'=>'required',
			// 'reg_pincode'=>'required|min_length[6]|max_length[6]'
			'reg_confirm_pwd'=>'matches[reg_pwd]',
		]);
		if (! $verify) {
			// $this->index();
			$data=['search'=>''];
			return view('home_page',$data);
		}else{
			return $this->reg_form();
		}

	}

	public function reg_form()
	{
		$auth = new user_db();
		if(isset($_POST['reg_submit']))
		{
			$request = \Config\Services::request();
			//$reg_name = $request->getPost("reg_name");

			$reg_mail = $request->getPost("reg_email");
			$reg_pwd = $request->getPost("reg_pwd");
			$reg_pwd_hash = password_hash($reg_pwd, PASSWORD_BCRYPT);

			// $reg_mob_cntry_code = $request->getPost("reg_num_append");
			// $reg_mob = $request->getPost("reg_mobile");
			// $reg_mob = $reg_mob_cntry_code.$reg_mob;
			// $reg_address = $request->getPost("reg_address");
			// $reg_pincode = $request->getPost("reg_pincode");

			$info = array(
				"name" => '',
				"email" => $reg_mail,
				"password" => $reg_pwd_hash,
				"address" => ''
			);
			

			try
			{
					$auth->insert($info);
					if ($auth) {
						$session = session();
		            	$session->set($info);
		            	$data = ['search'=>''];
						return view('user_home',$data);
						// $success['s_msg']="SUCCESSFULLY REGISTERED";
						// return view('home_page',$success);
					}
					else{
						// $fail['f_msg']="REGISTRATION FAILED";

						$data=[
							'search'=>'',
							'f_msg'=>'REGISTRATION FAILED'
						];
						return view('home_page',$data);
					}

			}
			catch (\Exception $e)
			{
			    $exception = $e->getMessage();
			    // $exception['f_msg'] = " MOBILE NUMBER ALREADY TAKEN , PLEASE USE ANOTHER MOBILE NUMBER";
				$data=[
							'search'=>'',
							'f_msg'=>$exception
						];
				return view('home_page',$data);
			}			
			$data = ['search'=>''];
			return view('home_page',$data);

		}
	}	

	public function login_validate(){
		$verify = $this->validate([
			'login_mobile'=>'min_length[10]|max_length[10]|is_unique[user_details.mobile]|regex_match[/^[7-9]{1}[0-9]{9}$/]',
			// 'login_pwd'=>'min_length[5]|max_length[20]',
		]);
		if (! $verify) {
			// $this->index();
			$data = ['search'=>''];
			return view('home_page',$data);
		}else{
			return $this->user_page();
		}
		// return view('home_page');

	}
	public function user_page()
	{

		$auth = new user_db();
		if(isset($_POST['login_submit']))
		{
			$request = \Config\Services::request();

			// $login_mob_cntry_code = $request->getPost("login_num_append");
			// $log_mob = $request->getPost("login_mobile");
			// $log_mob = $login_mob_cntry_code.$log_mob;
			$login_email = $request->getPost("login_email");
			$log_pwd = $request->getPost("login_pwd");

				try
			{
					$users= $auth->where([
						'email'=>$login_email
						])
		                ->find();
		            if ($users){
		            	$pwd_verify = password_verify($log_pwd, $users[0]['password']);
		            	if ($pwd_verify) {
		            		$data=[
			            	'name'=>$users[0]['name'],
			            	'email'=>$users[0]['email'],
			            	'address'=>$users[0]['address'],
			            	];
			            	$session = session();
			            	$session->set($data);
			            	$data = ['search'=>''];
							return view('user_home',$data);
							
		            	}else{
		            		$error="Invalid Password";
			            	$data = ['search'=>'','msg'=>$error];
							return view('home_page',$data);
		            	}

		            	
		            }
		            else{
		            	$error="User not found with given Mail ID";
		            	$data = ['search'=>'','msg'=>$error];
						return view('home_page',$data);
		            }
			}
			catch (\Exception $e)
			{
			    // die($e->getMessage());
			    $error=$e->getMessage();
		        $data = ['search'=>'','msg'=>$error];
				return view('home_page',$data);
			}

			


		}
	}

	public function s_destroy(){
		$session = session();
		$session->destroy();
		return $this->response->redirect(base_url('Home'));
	}




	public function edit_profile_validate(){
		$verify = $this->validate([
			'name_update'=>'alpha_numeric_space|min_length[3]|max_length[30]',
			'email_update'=>'min_length[6]|max_length[25]',
			'pincode_update'=>'min_length[6]|max_length[6]',
		]);
		if (! $verify) {
			return view('user_profile');
		}else{
			return $this->edit_profile();
		}
	}
	public function edit_profile(){
		$auth = new user_db();
		if(isset($_POST['update_submit']))
		{
			$request = \Config\Services::request();

			$name_update = $request->getPost("name_update");
			$email_update = $request->getPost("email_update");
			$address_update = $request->getPost("address_update");

			$update_data=[
				'name'=>$name_update,
				'address'=>$address_update
			];
		}
		$res = $auth->where('email',$email_update)
			->set($update_data)
			->update();

		if ($res) {
			$success['success_msg']="SUCCESSFULLY UPDATED";
				$session=session();
				$session->set($update_data);
				$success['success_msg']="PASSWORD SUCCESSFULLY UPDATED";
				return view('user_profile',$success);
		}else{
			$fail['fail_msg']="FAILED TO UPDATE";
			return view('user_profile',$fail);
		}
	}






	public function change_pwd_validate(){
		$verify = $this->validate([
			//'old_pwd'=>'min_length[5]|max_length[20]',
			'new_pwd'=>'min_length[5]|max_length[20]',
			'confirm_pwd'=>'matches[new_pwd]',
		]);
		if (! $verify) {
			return view('user_profile');
		}else{
			return $this->change_pwd();
	}
		}
	public function change_pwd(){
		$auth = new user_db();
		if(isset($_POST['change_pwd']))
		{
			$request = \Config\Services::request();

			$old_pwd = $request->getPost("old_pwd");
			$new_pwd = $request->getPost("new_pwd");
			
		}
		$session=session();
		$user_email=$session->get('email');

		$users = $auth->where(['email'=>$user_email])
					   ->find();
		if ($users) {
			$pwd_verify = password_verify($old_pwd, $users[0]['password']);
			if ($pwd_verify) {
				$new_pwd_hash = password_hash($new_pwd, PASSWORD_BCRYPT);
				$updated=$auth->where('email',$user_email)
						->set('password',$new_pwd_hash)	
						->update();
			
				if ($updated) {
					$success['success_msg']="PASSWORD SUCCESSFULLY UPDATED";
					return view('user_profile',$success);
	            	// return $this->response->redirect(base_url('Home/s_destroy'));
				}else{
					$fail['fail_msg']="NOT UPDATED";
					return view('user_profile',$fail);
				}
			}else{
				$fail['fail_msg']="PLEASE ENTER VALID OLD PASSWORD";

				return view('user_profile',$fail);
			}
		}else{
			$fail['fail_msg']="USER NOT FOUND";
			return view('user_profile',$fail);
		}


		// $res=$auth->where(['mobile'=>$user_mobile,'password'=>$old_pwd])
		// 	->findAll();
		// if ($res) {
		// 	$updated=$auth->where('mobile',$user_mobile)
		// 				->set('password',$confirm_pwd)	
		// 				->update();
			
		// 	if ($updated) {
		// 		$user_password_update['pwd_updated']="PASSWORD SUCCESSFULLY UPDATED";

		// 		return view('user_profile',$user_password_update);
  //           	// return $this->response->redirect(base_url('Home/s_destroy'));
		// 	}else{
		// 		echo "not updated";
		// 	}
		// }else{
		// 	$user_password_update_failed['pwd_update_fail']="PLEASE ENTER VALID OLD PASSWORD";
	 //       	return view('user_profile',$user_password_update_failed);
		// }
			// ->set(['name'=>$name_update,'email'=>$email_update,'address'=>$address_update])
			
			
				
	}

	public function search(){
				if (isset($_POST['search_home_page'])) {

						$data=[
							'search'=> $this->request->getVar('search'),
							'search_place'=>'home'
						];
						return view('home_page',$data);					

				}elseif (isset($_POST['search_user_home'])) {
						$data=[
							'search'=> $this->request->getVar('search'),
							'search_place'=>'user_home'
						];
						return view('user_home',$data);
				}
				
	}
	public function function_hall(){
		$session=session();
		$data=[
				'search'=> 'function',
			];
		if ($session->get('email')!=null) {
			return view('user_home',$data);
		}else{
			return view('home_page',$data);
		}
	}

	public function convention_hall(){
		$session=session();
		$data=[
				'search'=> 'convention',
			];
		if ($session->get('email')!=null) {
			return view('user_home',$data);
		}else{
			return view('home_page',$data);
		}
	}	

	public function party_room(){
		$session=session();
		$data=[
				'search'=> 'partyroom',
			];
		if ($session->get('email')!=null) {
			return view('user_home',$data);
		}else{
			return view('home_page',$data);
		}
	}		
	public function check_forgot_pwd_user(){
       $auth = new user_db();
        $request = \Config\Services::request();
        $forgot_password_user_email = $request->getPost("forgot_password_user_email");

        $users = $auth->where(['email'=>$forgot_password_user_email])
                       ->find();    
        if ($users) {
        	$mail = $forgot_password_user_email;
           	return $this->send_mail_link($mail);
        }else{
            $fail=[
                    'fail_msg'=> 'USER NOT FOUND',
                    'search'=>''
                    ];
            return view('home_page',$fail);
        }

	}
	public function send_mail_link($mail){
                $request = \Config\Services::request();
                $forgot_password_user_email = $mail;
                try {
                    $email = \Config\Services::email();

                    $config['protocol'] = 'mail';
                    $config['SMTPHost'] = 'https://bc3.000webhostapp.com';
                    $config['SMTPPort'] = '465';
                    $config['SMTPTimeout'] = '5';
                    $config['SMTPUser'] = 'itsmanipersonal@gmail.com';
                    $config['SMTPPass'] = 'manipwd235';
                    //'cztwvnvjfdlgkdop';
                    // $config['recipients'] = 'tmanideep235@gmail.com';

                    $config['charset']  = 'utf-8';
                    $config['mailType'] = 'text';

                    $email->initialize($config);

                    $email->setFrom('itsmanipersonal@gmail.com',"BlueCarpt"); //our site personal mail
                    $email->setTo($forgot_password_user_email);   //TO user


                    $email->setSubject('Link for generating new password');
                    // $email->setMessage('<div style="background-color:cyan;padding:10px;">
                    //                         <h4 style="color:black;">
                    //                                 Your password recovery link is 
                    //                         </h4>
                    //                         <a href="https://bc3.000webhostapp.com/Home/recovery/'.$forgot_password_user_email.'">Click Here</a>
                    //                     </div>');
                    $email->setMessage("click here");
                    if (! $email->send())
                    {
                        $fail=[
			                    'fail_msg'=>$email->printDebugger(),
			                    'search'=>''
			                    ];
			            return view('home_page',$fail);                    	

                    }else{
                        $success=[
			                    'success_msg'=>'MAIL SENT',
			                    'search'=>''
			                    ];
			            return view('home_page',$success);    
                    }
                }catch (\Exception $e) {
                         $fail=[
			                    'fail_msg'=>$e,
			                    'search'=>''
			                    ];
			            return view('home_page',$fail);    
                }
	}
	public function recovery($email){
		$data['user_mail']=$email;
		return view('forgot_password',$data);
	}
	public function verify_recovery(){
		$auth = new user_db();
        $request = \Config\Services::request();
        
        $forgot_user_mail = $request->getPost("forgot_user_mail");
        $new_password_field = $request->getPost("new_password_field");
        $confirm_password_field = $request->getPost("confirm_password_field");

        if ($new_password_field!=$confirm_password_field) {
        	$fail=[
                    'fail_msg'=> 'PASSWORD NOT MATCH',
                    'user_mail'=>$forgot_user_mail
                    ];
            return view('forgot_password',$fail);
        }
        $users = $auth->where(['email'=>$forgot_user_mail])
                       ->find();    
        if ($users) {
        	$confirm_password_field_hash = password_hash($confirm_password_field, PASSWORD_BCRYPT);
			$updated=$auth->where('email',$forgot_user_mail)
						->set('password',$confirm_password_field_hash)	
						->update();
			
			if ($updated) {
				$success=[
                    'success_msg'=> 'PASSWORD SUCCESSFULLY UPDATED',
                    'search'=>''
                    ];
            	return view('home_page',$success);
            	// return $this->response->redirect(base_url('Home/s_destroy'));
			}else{
				$fail=[
                    'fail_msg'=> 'PASSWORD NOT UPDATED',
                    'user_mail'=>$forgot_user_mail
                    ];
            	return view('forgot_password',$fail);
			}
        }else{
            $fail=[
                    'fail_msg'=> 'USER NOT FOUND',
                    'search'=>''
                    ];
            return view('home_page',$fail);
        }
	}
}
// $msg = 'Files has been uploaded';
// return redirect()->to( base_url('home') )->with('msg', $msg);