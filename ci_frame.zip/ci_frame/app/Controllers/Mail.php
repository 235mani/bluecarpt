<?php namespace App\Controllers;
use App\Controllers\BaseController;
class Mail extends BaseController
{

    public function index()
    {
            if (isset($_POST['help_submit_message'])) {
                $request = \Config\Services::request();

                $user_name = $request->getPost("user_name");
                $user_mail = $request->getPost("user_mail");
                $user_msg = $request->getPost("user_msg");

                try {
                    $email = \Config\Services::email();

                    $config['protocol'] = 'mail';
                    $config['SMTPHost'] = 'https://bc3.000webhostapp.com';
                    $config['SMTPPort'] = '465';
                    $config['SMTPTimeout'] = '5';
                    $config['SMTPUser'] = 'itsmanipersonal@gmail.com';
                    $config['SMTPPass'] = 'manipwd235';
                    //'cztwvnvjfdlgkdop';
                    // $config['recipients'] = 'tmanideep235@gmail.com';

                    $config['charset']  = 'utf-8';
                    $config['mailType'] = 'html';

                    $email->initialize($config);


                    $email->setFrom('itsmanipersonal@gmail.com'); //our site personal mail
                    $email->setTo('111manideep@gmail.com');   //our site official mail
                    // $email->setCC('another@another-gmail.com');
                    // $email->setBCC('them@their-gmail.com');

                    $email->setSubject('Email Test');
                    $email->setMessage('<div style="background-color:cyan;padding:10px;"><h4>'.$user_msg.'</h4></div>');
                    //$email->setHeader('111manideep@gmail.com', 'manideep');

                    
                    if (! $email->send())
                    {
                        echo $email->printDebugger();
                    }else{
                        try {
                                    $email = \Config\Services::email();

                                    $config['protocol'] = 'mail';
                                    $config['SMTPHost'] = 'https://bc3.000webhostapp.com';
                                    $config['SMTPPort'] = '465';
                                    //$config['SMTPTimeout'] = '7';
                                    $config['SMTPUser'] = 'itsmanipersonal@gmail.com';
                                    $config['SMTPPass'] = 'manipwd235';
                                    //'cztwvnvjfdlgkdop';
                                    // $config['recipients'] = 'tmanideep235@gmail.com';

                                    $config['charset']  = 'utf-8';
                                    $config['mailType'] = 'html';

                                    $email->initialize($config);


                                    $email->setFrom('itsmanipersonal@gmail.com','BlueCarpt Admin');
                                    $email->setTo($user_mail);
                                    // $email->setCC('another@another-gmail.com');
                                    // $email->setBCC('them@their-gmail.com');

                                    $email->setSubject('Email Test');
                                    $email->setMessage('<div style="background-color:green;padding:10px;"><h4>HELLO , '.$user_name.' Thanks for contacting us</h4></div>');
                                    $email->setHeader('111manideep@gmail.com', 'manideep');

                                    
                                    if (! $email->send())
                                    {
                                        echo $email->printDebugger();
                                    }else{
                                                $session=session();
                                                if ($session->get('email')!=null) {
                                                    $data = ['search'=>'','mail_sent'=>'Mail sent Successfully'];
                                                    return view('user_home',$data);
                                                }else{
                                                    $data=['search'=>'','mail_sent'=>'Mail sent Successfully'];
                                                    return view('home_page',$data);
                                                }
                                    }          
                                } catch (\Exception $e) {
                                    echo $e;
                                }
                    }            
                } catch (\Exception $e) {
                    echo $e;
                }
        }
    }
}