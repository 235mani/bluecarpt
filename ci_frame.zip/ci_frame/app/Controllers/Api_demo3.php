<?php namespace App\Controllers;
use CodeIgniter\RESTful\ResourceController;
use App\Models\API_db;
class Api_demo3 extends ResourceController
{
	// use \CodeIgniter\API\ResponseTrait;
	public function index(){
		$auth = new API_db();
		$posts= $auth->findAll();
		if ($posts!=NULL) {
			// return $this->respond($posts);
			return $this->response->setStatusCode(200)
								  ->setJSON($posts);			

		}else
		{
			echo "NO VALUES IN DB";
		}
		
	}
	public function create()
	{
		//helper(['form']);
		$rules = [
			'name'=>'required',
		];
		if (!$this->validate($rules)) {
			return $this->fail($this->validator->getErrors());
		}else{
			// $input = $this->request->getRawInput();
			
			$data=[
				'name'=> $this->request->getVar('name'),

				// 'name'=>$input['name']
			];
			$auth = new API_db();
			$result = $auth->insert($data);
			
		}
		// return $this->respondCreated("successfully registerd");
			return $this->response->setStatusCode(200)
								  ->setContentType('text/plain')
								  ->setBody("success")
								  ->setJSON($data);		
		// return $this->respondCreated($data);

	}

	public function show($id=NULL)
	{
		$auth = new API_db();
		$result = $auth->where(['id'=>$id])
						->find();
					// ->findAll();
		if ($result!=NULL) {
			return $this->respond($result);
		}else{
			echo "THERE IS NO DATA WITH GIVEN INPUT";
		}
		
	}

	public function delete($id=NULL)
	{
		$auth = new API_db();
		$data = $auth->where(['id'=>$id])
					->find();
		if ($data) {
			$auth->where(['id'=>$id])
				->delete();
			// return $this->respondDeleted($data);
				echo "deleted";
		}else{
			return $this->failNotFound('Record Not Found With Given Input');
		}
	}
}

