<?php 
  $session=session();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href=" <?php echo base_url('public/css/css_file.css'); ?> ">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>BlueCarpt</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<!--font awesome icons-->
<script src="https://kit.fontawesome.com/33c08b8109.js" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>




<style type="text/css">
.search{
  padding-top: 100px;

}



</style>
</head>
<body style="background-color:;">
<div class="menu">
    <nav class="navbar navbar-expand-md navbar-light fixed-top">
        <a href=""><img class="logo" src="<?php echo base_url('public/images/logo_white.png');?>"></a>         
        <a href="" class="navbar-brand" id="brand_name">BlueCarpt</a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="nav navbar-nav ml-auto">
                       <li class="nav-item">
                            <a href="<?php echo base_url('home/user_home');?>" class="nav-link" id="nav_lists" >
                              <b class="active_link">Home</b>
                            </a>
                            
                        </li>

                        <li class="nav-item dropdown">
                            <!--level 1 drop dowm-->
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" id="nav_lists">We Support</a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a tabindex="-1" href="#" class="dropdown-item dropdown-toggle" id="item1" data-toggle="dropdown">College events</a>
                                <!--level 2.1 drop dowm-->
                                        <div class="dropdown-menu dropdown-menu " id="level_1in2_drop">
                                            <a href="#"class="dropdown-item">Fest</a>
                                            <div class="dropdown-divider"></div>
                                            <a href="#"class="dropdown-item">MUN</a>
                                      <div class="dropdown-divider"></div>
                                      <a href="#"class="dropdown-item">Cultural Events</a>
                                      <div class="dropdown-divider"></div>
                                      <a href="#"class="dropdown-item">DJ Events</a>
                                     
                                        </div>  
                                <div class="dropdown-divider"></div>
                                <a href="#" class="dropdown-item dropdown-toggle" id="item2" data-toggle="dropdown">Other events</a>
                                <!--level 2.1 drop dowm-->
                                        <div class="dropdown-menu dropdown-menu " id="level_2in2_drop">
                                            <a href="#"class="dropdown-item">holi fest</a>
                                            <div class="dropdown-divider"></div>
                                            <a href="#"class="dropdown-item">Kite Festival</a>
                                      <div class="dropdown-divider"></div>
                                      <a href="#"class="dropdown-item">Dandia</a>
                                      <div class="dropdown-divider"></div>
                                      <a href="#"class="dropdown-item">Dussera Events</a>
                                      <div class="dropdown-divider"></div>
                                      <a href="#"class="dropdown-item">Eco-friendly Events</a>
                                        </div>

                               
                            </div>
                        </li>

                        <li class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" id="nav_lists">
                              <b class="">Our services</b></a>
                            <div class="dropdown-menu">
                                <a href="" class="dropdown-item" style="cursor:not-allowed;">
                                  <span >Banqute halls</span></a>
                                <div class="dropdown-divider"></div>
                                <a href="<?=base_url('home/function_hall')?>" style="cursor: pointer;" class="dropdown-item">
                                  <b class="">Function halls</b></a>
                                <div class="dropdown-divider"></div>
                                <a href="<?=base_url('home/convention_hall')?>" style="cursor: pointer;" class="dropdown-item"><b class="">Convention halls</b></a>
                                <div class="dropdown-divider"></div>
                                <a href="<?=base_url('home/Party_room')?>" style="cursor: pointer;" class="dropdown-item"><b class="">Party rooms</b></a>
                            </div>
                        </li>
                    

                        <li>
                            <a href="#footer" class="nav-link" id="nav_lists">contact us</a>
                        </li>
                        <b class="">
                            <a href="<?php echo base_url('home/user_profile');?>" class="nav-link" id="nav_lists"><i id="profile_icon" class="fas fa-user"></i></a>
                        </b>

                       
                    </ul>            
        </div>
    </nav>
</div>


<div class="container-fluid search">
      <form action="<?= base_url('home/search')?>" method="POST">
          <i class="fas fa-search" id="search_icon"></i>
          <input type="text" name="search" required placeholder="Search By Area" >
          <button class="btn btn-success btn-md btn" name="search_user_home" type="submit">Search</button>
      </form>
</div>


<div style="margin-top: 40px;margin-bottom:20px;" align="center">
            <?php
            if (isset($search_fail)) 
            {
            ?>
              <label class="alert alert-danger alert-dismissible fade show">
                <a href="#" class="close" data-dismiss="alert">&times</a>
                <?php 
                    echo "<b>".$search_fail."</b>";
                ?>  
              </label>
             <?php
            }elseif (isset($mail_sent)) 
            {
            ?>
              <label class="alert alert-success alert-dismissible fade show">
                <a href="#" class="close" data-dismiss="alert">&times</a>
                <?php 
                    echo "<b>".$mail_sent."</b>";
                ?>  
              </label>
             <?php
            }
            ?>
</div>
<?php 
    include_once(APPPATH.'/Views/hall_cards.php');
 ?>

<div class="footer" id="footer">  
      <?php 
        include 'footer.html';
       ?>
</div>


<script type="text/javascript" src=" <?php echo base_url('public/js/script.js'); ?> "></script>

</body>
</html>                            