<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href=" <?php echo base_url('public/css/css_file.css'); ?> ">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<script src="https://kit.fontawesome.com/33c08b8109.js" crossorigin="anonymous"></script>


</head>
<body>
<div class="container-fluid" id="card-body"> <!-- card container start -->
<div id="footer" class="footer">
  <?php 
include("footer.html");
 ?>      
</div>
<?php 
use App\Models\user_db;
    $con = new user_db();
    $users= $con->findAll();
    foreach($users as $x => $x_value) 
    {
?>

<div class="container-fluid" id="card-body"> <!-- card container start -->
      
      <div class="card_body_footer"> <!-- card start -->
        <div class="row" id="card_row">
            <div class="col-12 mt-3" id="">
                  <div class="card_column" id="card_shadow" onclick="hall_card();"  >
                      <a href="<?php echo base_url('Home/view_halls');?>"><img class="hall_card_col1" src="<?php echo base_url('public/images/hall8.jpeg');?>" alt="Card image cap"></a>
                  </div>

                  <div class="card_column" id="card_shadow" >
                            <div class="hall_card_col2" >
                                  <div class="col2_txt"  >
                                            <h2 class="col2_title"><b>
                                              <?= $x_value['name']?>
                                            </b></h2>
                                            <table  align="center">
                                            <tbody>
                                                    <tr>
                                                        <td><i class="fas fa-map-marker-alt"></i> &nbsp 
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fas fa-utensils"></i> &nbsp <span id="foodtype">
                                                          <?= $x_value['foodtype']?>
                                                        </span></td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fas fa-car"></i> &nbsp <span id="parking">
                                                          <?= $x_value['parking']?>
                                                        </span></td>
                                                    </tr>
                                                    <tr>
                                                        <td><i class="fas fa-person-booth"></i> &nbsp <span id="rooms">
                                                          <?= $x_value['rooms']?>
                                                        </span></td>
                                                    </tr>                                                                                               
                                            </tbody>
                                    </table>
                                  </div>                                                  
                            </div>
                  </div>

                  <div class="card_column" id="card_shadow" >
                            <div class="hall_card_col3" >
                                              <div class=" col3_txt" id="" style="border-bottom:1px solid silver;" >
                                                      <h5 class="col3_title"><b>Pricing </b></h5>
                                                      <table align="center">
                                                        <tbody>
                                                            <tr>
                                                                <td><b>Rental Price</b></td>
                                                                <td><i class="fas fa-rupee-sign" id="price_icon"></i>  <span id="price"><?= $x_value['rent_price']?></span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><b>per plate</b></td>
                                                                <td><i class="fas fa-rupee-sign" id="price_icon"></i>  <span id="perplate"><?= $x_value['price_per_plate']?></span></td>
                                                            </tr>

                                                        </tbody>
                                                      </table>
                                                  </div>
                                                  
                                                  <div class="col3_txt">
                                                      <h5 class="col3_title"><b>Capacity </b></h5>
                                                        <table align="center">
                                                        <tbody>
                                                            <tr>
                                                                <td><b>Hall</b></td>
                                                                <td><span id="capacity">
                                                                  <?= $x_value['capacity']?>
                                                                </span></td>
                                                            </tr>
                                                            <tr>
                                                                <td><b>Lawn</b></td>
                                                                <td><span id="capacity2">
                                                                  <?= $x_value['capacity']?>
                                                                </span></td>
                                                            </tr>
                                                                                                                
                                                        </tbody>
                                                      </table>
                                                </div>
                            </div>
                  </div>
            
                
            </div>       
        </div>
        <div class="card-footer" id="card_shadow" style="background-color:#8ec3eb;">
                                    <div class="card_visit">
                                      <a href="<?php echo base_url('Home/view_halls');?>"><button class="btn btn-sm btn-primary">Visit for more</button></a>
                                    </div>
                                     <div class="card_ratting"><b><?= $x_value['ratting']?></b>

                                        <span class="fa fa-star card_ratting_checked"></span>
                                        <span class="fa fa-star card_ratting_checked"></span>
                                        <span class="fa fa-star card_ratting_checked"></span>
                                        <span class="fa fa-star"></span>
                                        <span class="fa fa-star"></span>
                                        
                                     </div> 
        </div>

    </div> <!-- card end -->
</div>

<?php

    }

 ?>

</div>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>