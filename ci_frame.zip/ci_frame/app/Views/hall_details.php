<?php 
  $session=session();
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" type="text/css" href=" <?php echo base_url('public/css/css_file.css'); ?> ">
<!-- <link rel="stylesheet" type="text/css" href="css/lightbox.min.css"> -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>BlueCarpt</title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<!--font awesome icons-->
<script src="https://kit.fontawesome.com/33c08b8109.js" crossorigin="anonymous"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<!-- @import calender css -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />

<!-- @import time css -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.css" integrity="sha256-WzVuf5oOPfz9nfgb4l3sFKzwoa++0DJdjLJkLWVgvhs=" crossorigin="anonymous" />


  <style type="text/css">


  </style>


</head>
<body>
<?php 
      include_once(APPPATH.'/Views/popups.php');
?>

<?php 
    if (isset($get_data)) 
    {
        $id = $get_data;
    }
    use App\Models\hall_db;
    $con = new hall_db();
    $users= $con->where([
       'id'=>$id,
     ])
    ->findAll();
    foreach($users as $x => $x_value) 
    {
?>
<div class="container-fluid">
  
    <div class="col-lg-12 col1 " id="card_shadow">
        <h5><b>NAME : </b><?= ucwords($x_value['title'])?></h5>
        <h5><b>ADDRESS : </b><?= ucwords($x_value['full_address'])?></h5>
        <h5><b>HALL RENT : </b> <i class="fas fa-rupee-sign" id="price_icon">
        </i><span><?= ucwords($x_value['rent'])?> </span> </h5>
    </div>
    <div class="col2_col3">
      <!-- <div class="row"> -->
      <div class="col2" id="card_shadow">
            <div id="silde_target" class="carousel slide" data-ride="carousel">
              <!-- Indicators -->
                    <ul class="carousel-indicators">
                      <li data-target="#silde_target" data-slide-to="0" class="active"></li>
                      <li data-target="#silde_target" data-slide-to="1"></li>
                      <li data-target="#silde_target" data-slide-to="2"></li>
                    </ul>
                    
                    <!-- The slideshow -->
                    <div class="carousel-inner">
                      <div class="carousel-item active">
                        <img src="<?php echo base_url('public/images/hall7.jpeg');?>" alt="Los Angeles" width="1100" height="500">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php echo base_url('public/images/hall8.jpeg');?>" alt="Chicago" width="1100" height="500">
                      </div>
                      <div class="carousel-item">
                        <img src="<?php echo base_url('public/images/hall6.jpeg');?>" alt="New York" width="1100" height="500">
                      </div>
                    </div>
                    
                    <!-- Left and right controls -->
                    <a class="carousel-control-prev" href="#silde_target" data-slide="prev">
                      <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#silde_target" data-slide="next">
                      <span class="carousel-control-next-icon"></span>
                    </a>
              </div>            
      </div>
      <div class="col3 " id="card_shadow">
            
         <div class="hall-view-card_shadows">
                    <h4 >FOOD TYPE</h4>
                       <table align="center">
                            <tbody>
                                <tr>
                                    <td><img src="https://img.icons8.com/color/20/000000/vegetarian-food-symbol.png" id="food"></td>
                                    <td>Vegetaraian</td>
                                    <td><i class="fas fa-rupee-sign" id="price_icon"></i> <?= ucwords($x_value['veg_price'])?></td>
                                </tr>
                                <tr>
                                    <td><img src="https://img.icons8.com/color/20/000000/non-vegetarian-food-symbol.png" id="food"></td>
                                    <td>Non-Vegetaraian</td>
                                    <td><i class="fas fa-rupee-sign" id="price_icon"></i> <?= ucwords($x_value['non_veg_price'])?></td>
                                </tr>

                             </tbody>
                      </table>
                      <hr>

                      <h4>SEATING</h4>
                      
                      <div class="seating_left"> 
                        hall<br><?= ucwords($x_value['hall_capacity'])?>
                      </div>
                      
                      <div class="seating_right">
                        Lawn<br><?= ucwords($x_value['hall_capacity'])?>
                      </div>
                      <br><br>
                      <hr>
                       
                        <form action="" method="">
                          <h4 >CHECK AVAILABILITY</h4>
                          <div id="valid_date" class="input-group date" data-date-format="dd-M-yyyy">
                            <input class="form-control" type="text" style="text-align: center;" readonly placeholder="Enter Your Date" />
                            <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                        </div>
                          <br>
                          <button type="button" class="btn btn-success ">CHECK</button>
                        </form><br>

                        <?php 

                            $val= $x_value['id'];
                            $session=session();
                            if ($session->get('email')!=null) {
                        ?>
                        <a href="<?=base_url('home/booking_page')?><?php echo "/".$val?>"><button class="btn btn-block btn-success">BOOK NOW</button></a>
                        <?php
                            }else{
                        ?>

                        <a href="" class="btn btn-block btn-success" data-target="#loginModal" data-toggle="modal" id="nav_lists">BOOK NOW</a>


                        <?php
                            }
                        ?>
                

                         

              </div>
          </div>
        </div>
    <div class="col4  " id="card_shadow">
          
        <div class="gal_tabs">
          <button class="tablinks active"  onclick="openCity(event, 'hall_images')">Hall Images</button>
          <button class="tablinks" onclick="openCity(event, 'Dining_images')">Dining Images</button>
          <button class="tablinks" onclick="openCity(event, 'Previous_celebrations')">Celebrations</button>
        </div>

        <div id="hall_images" class="tabcontent hall-view-card_shadows" style="display:block;">
            <div class="gallery ">
              
              <a href="<?php echo base_url('public/images/hall4.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall4.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall3.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall3.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall2.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall2.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall1.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall1.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall5.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall5.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall6.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall6.jpeg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall7.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall7.jpeg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall8.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall8.jpeg');?>" id="big"></a>

              
          </div>
        </div>

        <div id="Dining_images" class="tabcontent hall-view-card_shadows">
            <div class="gallery">
              <a href="<?php echo base_url('public/images/hall6.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall6.jpeg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall7.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall7.jpeg');?>" id="big"></a><a href="<?php echo base_url('public/images/hall4.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall4.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall3.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall3.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall1.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall1.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall2.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall2.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall1.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall1.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall8.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall8.jpeg');?>" id="big"></a>
          </div>
        </div>

        <div id="Previous_celebrations" class="tabcontent hall-view-card_shadows">
            <div class="gallery">
              <a href="<?php echo base_url('public/images/hall2.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall2.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall1.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall1.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall2.jpg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall2.jpg');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall1.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall1.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall5.jfif');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall5.jfif');?>" id="big"></a>
              <a href="<?php echo base_url('public/images/hall6.jpeg');?>" id="small" data-lightbox="mygallery" data-title="hall"><img src="<?php echo base_url('public/images/hall6.jpeg');?>" id="big"></a>
          </div>
        </div>
    </div>
    

    <div class="col5  " id="card_shadow">
            <h5><b>ABOUT :</b> <?= ucwords($x_value['about_hall'])?></h5>
    </div>

    <div class="col6"  id="card_shadow">
      <div class="loader" >

        </div>
        <h1 >For Google Ad's</h1>
    </div>

</div>


<div class="footer">  
<?php 
  include("footer.html");
 ?>
</div>


    

<script type="text/javascript" src=" <?php echo base_url('public/js/script.js'); ?> "></script>     
<!-- <script type="text/javascript" src="js/lightbox-plus-jquery.min.js"></script>  -->     

<!-- @import calender js
jQuery.js -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>

<!-- @import time js-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/clockpicker/0.0.7/bootstrap-clockpicker.js" integrity="sha256-OIIIhnfeTrz7TTtNh60DMH8U7bNMBH+noeMzo2uSJTI=" crossorigin="anonymous"></script>
<?php

    }

 ?>
</body>
</html>