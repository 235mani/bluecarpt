<?php namespace App\Models;

use CodeIgniter\Model;

class user_db extends Model
{
		
		
        protected $table = 'user_details';
        protected $primarykey = 'email';
        protected $returnType = 'array';
        protected $allowedFields = ['name','email','password','address'];
}