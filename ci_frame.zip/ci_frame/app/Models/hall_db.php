<?php namespace App\Models;

use CodeIgniter\Model;

class hall_db extends Model
{
		//id12829917_u_proj_x <-uname
		//id12829917_proj_x <-db name
		//Key_2_stepup<-pwd
		//id12829917_bc <- db name
        protected $table = 'hall_details';
        protected $primarykey = 'id';
        protected $returnType = 'array';
        // protected $allowedFields = ['id','name','area','foodtype','parking','rooms','rent_price','price_per_plate','capacity','complete_address','ratting'] ;
        protected $allowedFields =['title','coolant','food_type','full_address','parking','hall_capacity','location','rating','rent','image','veg_price','non_veg_price','hall_type'];
        //10 fields
}